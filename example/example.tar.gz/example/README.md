Example Vault config
====================

This directory is an example vault configuration for testing vaultsmith
